﻿using EmployeeAttendanceSystem6.Models;
using Microsoft.EntityFrameworkCore;

namespace EmployeeAttendanceSystem6.Data
{
    public class WebDbContext : DbContext
    {
        public WebDbContext(DbContextOptions<WebDbContext> options)
            : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
            // أضف تخصيصات إضافية للنماذج إذا لزم الأمر
        }

        public DbSet<Employee> Employees { get; set; }
        public DbSet<Department> Departments { get; set; }
        public DbSet<Role> Roles { get; set; }
        public DbSet<Attendance> Attendances { get; set; }
        public DbSet<User> Users { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=DESKTOP-0QI3GQI\\SQLEXPRESS02;Initial Catalog=mar;Integrated Security=True;Trust Server Certificate=True ");
        }
        public DbSet<EmployeeAttendanceSystem6.Models.main> main { get; set; } = default!;
    }
}
