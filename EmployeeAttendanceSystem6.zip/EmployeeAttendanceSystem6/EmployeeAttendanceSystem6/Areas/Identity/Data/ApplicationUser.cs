﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations.Schema;

namespace EmployeeAttendanceSystem6.Areas.Identity.Data
{
    // Add profile data for application users by adding properties to the ApplicationUser class
    public class ApplicationUser : IdentityUser
    {
        [PersonalData] // This marks it as personal data in Identity
        [Column(TypeName = "nvarchar(100)")]
        public string FirstName { get; set; }

        [PersonalData] // This marks it as personal data in Identity
        [Column(TypeName = "nvarchar(100)")]
        public string LastName { get; set; }
    }
}
