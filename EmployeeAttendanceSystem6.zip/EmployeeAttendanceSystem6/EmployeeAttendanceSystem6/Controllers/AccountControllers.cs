﻿using EmployeeAttendanceSystem6.Data;
using EmployeeAttendanceSystem6.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text;
using System.Security.Cryptography;

namespace EmployeeAttendanceSystem6.Controllers
{

    public class AccountController : Controller
    {
        private readonly WebDbContext _context;

        public AccountController(WebDbContext context)
        {
            _context = context;
        }

        // GET: Register
        public IActionResult Register()
        {
            return View();
        }

        // POST: Register
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Register(RegisterViewModel model)
        {
            if (ModelState.IsValid)
            {
                // Check if username already exists
                if (_context.Users.Any(u => u.Username == model.Username))
                {
                    ModelState.AddModelError("", "Username already exists.");
                    return View(model);
                }

                var user = new User
                {
                    Username = model.Username,
                    Password = HashPassword(model.Password), // Hash the password
                    Email = model.Email
                };

                _context.Users.Add(user);
                _context.SaveChanges();
                return RedirectToAction("Login");
            }
            return View(model);
        }

        // GET: Login
        public IActionResult Login()
        {
            return View();
        }

        // POST: Login
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Login(LoginViewModel model)
        {
            if (ModelState.IsValid)
            {
                var hashedPassword = HashPassword(model.Password); // Hash the incoming password
                var user = _context.Users.FirstOrDefault(u => u.Username == model.Username && u.Password == hashedPassword);
                if (user != null)
                {
                    // Implement authentication (e.g., set session or cookie)
                    // For example, you can use HttpContext.Session or cookies here
                    return RedirectToAction("Create", "mains");
                }
                ModelState.AddModelError("", "Invalid login attempt.");
            }
            return View(model);
        }

        private string HashPassword(string password)
        {
            using (var sha256 = SHA256.Create())
            {
                var bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                return Convert.ToBase64String(bytes);
            }
        }
    }

}
