﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace EmployeeAttendanceSystem6.Models
{
    public class Attendance
    {
        [Key]
        public int AttendanceId { get; set; }

        public int EmployeeId { get; set; }

        [Required]
        public DateTime AttendanceDate { get; set; }

        // إضافة خاصية IsPresent لتحديد ما إذا كان الموظف حاضرًا
        public bool IsPresent { get; set; } // true = Present, false = Absent

        [ForeignKey("EmployeeId")]
        public Employee Employee { get; set; }
    }
}
