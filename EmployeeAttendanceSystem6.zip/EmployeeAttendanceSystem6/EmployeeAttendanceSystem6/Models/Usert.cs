﻿using System.ComponentModel.DataAnnotations;

namespace EmployeeAttendanceSystem6.Models
{
    public class Usert
    {
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string Username { get; set; }

        [Required]
        [StringLength(100)]
        public string Password { get; set; } // Consider hashing this

        [Required]
        [EmailAddress]
        public string Email { get; set; }
    }
}
