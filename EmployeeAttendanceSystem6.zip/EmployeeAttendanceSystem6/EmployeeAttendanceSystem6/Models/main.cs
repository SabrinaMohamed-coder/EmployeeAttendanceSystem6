﻿namespace EmployeeAttendanceSystem6.Models
{
    public class main
    {
        public int Id {get; set;}
        public string firstname { get; set; }
        public string lastname { get; set; }
        public string adress { get; set; }
        public int telnum { get; set; }
        public string emil { get; set; }
        public int salary { get; set; }





    }
}
